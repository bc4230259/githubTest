package com.igeek.homework3;

public interface USB {

	public void on();
	public void off();
	public void workMethod();
	
}

package com.igeek.homework3;

public abstract class Hardware {
	public abstract void workMethod();
}

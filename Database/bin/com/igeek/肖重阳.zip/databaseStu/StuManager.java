package com.igeek.databaseStu;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class StuManager {
	private Connection cn;
	private PreparedStatement ps=null;
	private String sql;
	public StuManager(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test?user=root&password=123456");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	
	}
	public void findAll(){
		 sql="select * from stu";
		
		try {
			ps=cn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				System.out.print("id\t");
				System.out.print("sno\t");
				System.out.print("name\t");
				System.out.print("score\t");
				System.out.print("age");
				System.out.println();
				for(int i=0;i<5;i++){
					System.out.print(rs.getObject(i+1)+"\t");
				}
				System.out.println();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
	}
	public void addStu(String sno,String name,int age,int score){
		 sql="insert into stu (sno,name,age,score) values(?,?,?,?)";
		try {
			ps=cn.prepareStatement(sql);
			ps.setObject(1, sno);
			ps.setObject(2, name);
			ps.setObject(3, age);
			ps.setObject(4, score);
			int i =ps.executeUpdate();
			if(i>0){
			System.out.println("���ӳɹ���");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
		
		
		
	}
	
	public void deleteStu(String sno){
		 sql= "delete from stu where sno=?";
		 try {
			ps=cn.prepareStatement(sql);
			ps.setObject(1, sno);
			int i =ps.executeUpdate();
			if(i>0){
				System.out.println("ɾ���ɹ�");
			}else{
				System.out.println("������˼,��Ҫɾ����ѧ�Ŷ�Ӧ��ѧ����Ϣ������,���ȥ�������ѡ��");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
		 
			}
	public void updateStu(String sno,int score){
		sql="update stu set score=? where sno=?";
		try {
			ps=cn.prepareStatement(sql);
		
		ps.setObject(1, score);
		ps.setObject(2, sno);
		int i =ps.executeUpdate();
		if(i>0){
			System.out.println("���ֳɹ�");
		}else{
			System.out.println("������˼,��Ҫ�޸ĵ�ѧ�Ŷ�Ӧ��ѧ����Ϣ������,���ȥ�������ѡ��");
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
		
		}
	
	public void search(String sno){
		sql="select * from stu where sno=?";
		try {
			ps=cn.prepareStatement(sql);
			ps.setObject(1, sno);
			ResultSet rs=ps.executeQuery();
			int flag=0;
			while(rs.next()){
				System.out.print("id\t");
				System.out.print("sno\t");
				System.out.print("name\t");
				System.out.print("score\t");
				System.out.print("age");
				System.out.println();
				for(int i=0;i<5;i++){
					System.out.print(rs.getObject(i+1)+"\t");
				}
				System.out.println();
				flag++;
			}
			if(flag<1){
				System.out.println("û����Ӧ��Ϣ");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
	}
	
	public void pageSearch(int pageNo){
		sql="select * from stu order by sno limit ?,?";
		try {
			ps=cn.prepareStatement(sql);
			ps.setInt(1, (pageNo-1)*3);
			ps.setInt(2, (pageNo-1)*3+3);
			ResultSet rs=ps.executeQuery();
			int flag=0;
			while(rs.next()){
				System.out.print("id\t");
				System.out.print("sno\t");
				System.out.print("name\t");
				System.out.print("score\t");
				System.out.print("age");
				System.out.println();
				for(int i=0;i<5;i++){
					System.out.print(rs.getObject(i+1)+"\t");
				}
				System.out.println();
				flag++;
			}
			if(flag<1){
				System.out.println("û����Ӧ��Ϣ");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void psClose(){
		try {
		
			cn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
//	private void importStu(){
//		try{
//		FileReader fr= new FileReader("Stu.txt");
//		BufferedReader br=new BufferedReader(fr);
//		String receiver="1";
//		while((receiver=br.readLine())!=null){
//			Student stu=new Student(receiver.split(",")[0],receiver.split(",")[1],Integer.parseInt(receiver.split(",")[2]),receiver.split(",")[3]);
//			this.al.add(stu);
//		}
//		fr.close();
//		br.close();
//		}
//		catch(Exception e){
//			System.out.println("δ�ҵ��ļ�������������");
//		}
//	}
	
//	public void ExportStu() throws Exception{
//		FileWriter fw= new FileWriter("Stu.txt");
//		BufferedWriter bw=new BufferedWriter(fw);
//		for (int i = 0; i < this.al.size(); i++) {
//			Student stuTemp=this.al.get(i);
//			String temp=stuTemp.getSno()+","+stuTemp.getName()+","+stuTemp.getAge()+","+stuTemp.getAddress();
//			bw.write(temp);
//			bw.newLine();
//		}
//		bw.flush();
//		bw.close();
//		fw.close();
//		
//	}
	
}
